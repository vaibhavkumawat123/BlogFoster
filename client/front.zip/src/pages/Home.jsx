import React from 'react';
import Post from '../components/Post';
import Hero from '../components/Hero';
// import Loader from '../components/Loader';

const Home = () => {
  return (
  <>
  {/* <Loader /> */}
  <Hero />
  <Post />
  </>
  )
}

export default Home