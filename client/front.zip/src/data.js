import post1 from "./assets/blog1.jpg";
import post2 from "./assets/blog2.jpg";
import post3 from "./assets/blog3.jpg";
import post4 from "./assets/blog4.jpg";

export const DUMMY_POST = [
    {
      id: "1",
      thumbnail: post1,
      category: "eductaion",
      title: "This is the title of the very first post on this page",
      desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad excepturi maiores odio similique unde asperiores id et perferendis nesciunt. Beatae rerum cumque natus fugit provident illum repudiandae esse repellat dolorum?",
      authorID: 3,
    },
    {
      id: "2",
      thumbnail: post2,
      category: "science",
      title: "This is the title of the very first post on this page",
      desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad excepturi maiores odio similique unde asperiores id et perferendis nesciunt. Beatae rerum cumque natus fugit provident illum repudiandae esse repellat dolorum?",
      authorID: 1,
    },
    {
      id: "3",
      thumbnail: post3,
      category: "weather",
      title: "This is the title of the very first post on this page",
      desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad excepturi maiores odio similique unde asperiores id et perferendis nesciunt. Beatae rerum cumque natus fugit provident illum repudiandae esse repellat dolorum?",
      authorID: 13,
    },
    {
      id: "4",
      thumbnail: post4,
      category: "farming",
      title: "This is the title of the very first post on this page",
      desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad excepturi maiores odio similique unde asperiores id et perferendis nesciunt. Beatae rerum cumque natus fugit provident illum repudiandae esse repellat dolorum?",
      authorID: 11,
    },
  ];