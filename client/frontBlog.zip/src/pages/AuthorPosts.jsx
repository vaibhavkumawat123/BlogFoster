import React, { useState } from 'react'
import { DUMMY_POST } from '../data'
import PostItem from '../components/PostItem'

const AuthorPosts = () => {

  const [posts , setPosts ] = useState(DUMMY_POST);

  return (
    <section className="posts">
    {
      posts.length > 0 ?   <div className="container posts_container">
      {posts.map(({ id, title, thumbnail, desc, category , authorID }) => (
        <PostItem
          postID={id}
          title={title}
          post={thumbnail}
          description={desc}
          category={category}
          authorID={authorID}
        />
      ))}
    </div> : <h2 className="center">No posts</h2>
    }
    </section>
  )
}

export default AuthorPosts