import React from 'react';
import Post from '../components/Post';

const Home = () => {
  return (
  <>
  <Post />
  </>
  )
}

export default Home