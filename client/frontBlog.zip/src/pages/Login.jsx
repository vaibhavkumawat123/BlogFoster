import React, { useState } from 'react'
import { Link } from 'react-router-dom';

const Login = () => {

  const [userData, setUserData] = useState({
 
    email:'',
    password:'',
 
  });

  const changeInputHandler = (e) =>{

    setUserData(prevState => {

      return {...prevState, [e.target.name]: e.target.value}

    });

  }

  return (
    <section className='login'>
        <div className="container">
          <h2>Login</h2>
          <form action="" className='form register_login'>
            <p className='form_error-message'>This is an error message</p>
           
            <input type="email" name='email'  placeholder='Email' value={userData.email} onChange={changeInputHandler}/>
            <input type="password" name='password'  placeholder='password' value={userData.password} onChange={changeInputHandler}/>
            <button type='submit' className='btn primary'>Login</button>
          </form>

          <small>don't have an account? <Link to={'/register'}>register</Link></small>
        </div>

    </section>
  )
}

export default Login