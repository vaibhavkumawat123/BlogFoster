import React from 'react'
import PostAuther from '../components/PostAuther'
import { Link } from 'react-router-dom'
import post from '../assets/blog22.jpg'

const PostDetail = () => {
  return (
    <>
    <section className="post-detail">

    <div className="container post-detail_container">

    <div className="post-detail_header">

    <PostAuther />

    <div className="post-detail_buttons">
      <Link to={'/posts/werwer/edit'} className='btn sm primary'>Edit</Link>
      <Link to={'/posts/werwer/delete'} className='btn sm primary'>Delete</Link>
    </div>

    </div>

    <h1>This is the post title!</h1>

    <div className="post-detail_tumbnail">
      <img src={post} alt="" />
    </div>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex non animi omnis labore quas temporibus in et? Eos commodi aliquam nesciunt eum assumenda, pariatur earum officiis! Est saepe vero distinctio iure tenetur reprehenderit. Possimus sequi dolore iste excepturi ipsa neque atque amet doloribus vero aspernatur tempora, animi maiores laudantium illo repellat et, eligendi incidunt. Quo quae sequi dicta voluptatum earum aliquid iure magnam libero facere quasi nobis provident maxime praesentium sint dolores, vel officiis facilis dolorem perferendis maiores non aut, consequuntur explicabo. Rem voluptate eveniet, aliquam, a quae nisi nam odio, earum nesciunt explicabo doloribus quis. Hic non maxime quod sit odit dicta, sint porro quae? Vero, sit nobis? Temporibus quidem dolore dolores accusantium! Voluptatum quia minima ut, ea </p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia vel nobis labore vitae ipsum fugiat sint libero, consectetur, error temporibus dicta optio? Molestiae nihil facilis praesentium odio voluptate, eligendi aperiam.</p>
    </div>

    </section>
    </>
  )
}

export default PostDetail