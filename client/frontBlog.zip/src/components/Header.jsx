import React from 'react';
import { Link } from 'react-router-dom';
import logo from '../assets/logo.png';
import { MdMenu } from "react-icons/md";
import { IoClose } from "react-icons/io5";


const Header = () => {
  return (
    <nav>
      <div className="container nav_container">
          <Link to={''} className='nav_logo'>
          <img src={logo} alt="" />
          </Link>
        
        <ul className='nav_menu'>
          <li><Link to={'/profile/sfdas'}>Aman</Link></li>
          <li><Link to={'/create'}>Create Post</Link></li>
          <li><Link to={'/authors'}>Authors</Link></li>
          <li><Link to={'/logout'}>Logout</Link></li>
        </ul>

        <button className='nav_toggle-btn'>
          <IoClose />
        </button>
      
      </div>

     
    </nav>
  )
}

export default Header